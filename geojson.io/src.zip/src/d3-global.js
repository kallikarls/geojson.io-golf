// import d3 and make it globally available
const d3 = require('d3');
window.d3 = d3;
